###Flask+celery实现异步web服务器

####需求
>近期为了实现一个内部的iOS IPA打包服务器，需要服务器拥有这样的特性：
>1. 异步处理打包过程，及时响应客户端请求信息
>2. 定期返回打包状态，通知所有客户端服务器状态
>
>上一篇文章探讨了搭建Flask web服务端，并且实现了websocket通信的需求。但Flask原生是单进程服务，无法支持多线程异步请求。所以需要用到**Celery**的扩展包。

####Celery-分布式任务队列（[文档](http://docs.jinkan.org/docs/celery/)）
>Celery 是一个简单、灵活且可靠的，处理大量消息的分布式系统，并且提供维护这样一个系统的必需工具。
>**任务队列**是一种在线程或机器间分发任务的机制。

####安装
```powershell
pip install celery
```
####使用
>**编写Celery函数**：
> ```python
@(马克飞象)celery.task()                                                                              
def background_task():
	time.sleep(10)                                                                               
	print("\n background_task................\n") 
> ```
>**调用Celery函数**：
> ```python
@socketio.on('build event')
def handle_build_event(json):
	# background_task.delay()
	buildIPA.delay()
> ```

**服务端代码**
```python
import flask
from flask import Flask,request,render_template
from flask_socketio import SocketIO,emit
from celery import Celery
import eventlet
eventlet.monkey_patch()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'

app.config.update(
    CELERY_BROKER_URL='redis://localhost:6379',
    CELERY_RESULT_BACKEND='redis://localhost:6379'
)

async_mode = 'eventlet'
socketio = SocketIO(app,async_mode=async_mode)
celery = Celery(app.name,broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)

# 响应编译事件
@socketio.on('build event')
def handle_build_event(json):
	print(json)
	# 调用celery函数
	# background_task.delay()
	buildIPA.delay()

#编写celery函数
@celery.task()                                                                              
def background_task():
	time.sleep(10)                                                                               
	print("\n background_task................\n") 
	 
@celery.task()
def buildIPA():
    print(u"\n 打包开始................\n")
    changeBuildState(Build_State.Packing)
    ipaFile = pack()

    if os.path.exists(ipaFile) == False:
		changeBuildState(Build_State.Error)		
		return

    print(u"\n 上传开始................\n")
	#示例
```


好吧，这里又用到了redis的服务。为什么要用到redis呢？我的理解是Celery是干活的人，干活的去哪里领任务呢？去redis里领取任务。

####redis环境搭建
>1、到官网上下载redis,我下载的版本是3.2.6
官网地址：http://redis.io/
2、将下载下来的tar.gz 压缩包拷贝到usr/local目录下，**解压**

>进入usr目录，终端中输入(请根据自己的目录调整)：
>```powershell
sudo chmod -R 777 /usr/local/redis-3.2.6/redis.conf
sudo chmod -R 777 /usr/local/redis-3.2.6
>```
3、编译测试：sudo make test
4、redis安装: sudo make install

运行redis服务
```powershell
// 启动,默认端口6379
redis-server
// 关闭
redis-cli shutdown
```
redis启动后样子大概类似下图：
![Alt text](./1481817451358.png)

####运行celery

终端进入我们的工程目录，运行（其中server是python文件的名称）：
```powershell
celery -A server.celery -P eventlet worker -l info
```
运行后如下图：
![Alt text](./1481817416539.png)

其中[tasks]列表中有，代表已经注册到消息列表中的任务类型，现在可以接受这2种任务类型的调用。
```powershell
[tasks]
  . server.background_task
  . server.buildIPA
```

####使用
>1. 首先**Ctrl+B**运行服务端进程
>2. 再运行Celery进程
>3. 从web前端发送请求至服务端，服务端调用Celery进程进行异步任务的处理

