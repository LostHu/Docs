###Swagger初探

@(马克飞象)[swagger, osx, 系统, API, 搭建]


####项目需求：
- 简明的服务端API文档，方便前后端进行交流
- **可以在线测试接口**
- 文档方便编辑、传输的标准公开格式（MarkDown、YAML、JSON）
- 可选：*自动化根据代码生成接口文档，或者根据文档生成代码*

####名词解释
>[Swagger™](http://swagger.io/)的目标是为REST APIs 定义一个标准的，与语言无关的接口，使人和计算机在看不到源码或者看不到文档或者不能通过网络流量检测的情况下能发现和理解各种服务的功能。当服务通过Swagger定义，消费者就能与远程的服务互动通过少量的实现逻辑。类似于低级编程接口，**Swagger去掉了调用服务时的很多猜测**。*Swagger是一组[开源项目](https://github.com/swagger-api/)*，支持**YAML**和**Json**格式。
> - [Swagger UI](https://github.com/swagger-api/swagger-ui)负责文档展现[官网Demo](http://petstore.swagger.io/)
> - [Swagger Editor](https://github.com/swagger-api/swagger-editor)负责文档编辑[官网Demo](http://editor.swagger.io/#/)
> - [Swagger Codegen](https://github.com/swagger-api/swagger-codegen)一个模板驱动引擎，通过分析用户Swagger资源声明以各种语言生成客户端代码（本文不作讨论）

####界面
Swagger UI![SwaggerUI](./1480564924850.png)
![Alt text](./1480579780639.png)


Swagger Editor![Alt text](./1480566290742.png)

####OSX环境搭建
本文主要基于OSX环境，首先需要安装Node.js包括npm环境，下载Swagger工程
环境要求：
>  
- Node.js
- Swagger UI工程
- Swagger Editor工程


####开启Swagger服务

``` python
 cd ~\Swagger(UI|Editor)
 http-server -p 9000
```
好了现在可以使用浏览器愉快的访问你的Swagger服务了
http://localhost:9000


#####1.编辑器选择
> - 使用**Swagger-Editor**在线编辑文档，Commit修改后的本地文档至GitHub；
> *优点*：代码高亮，随时随地编辑，可视化
> *缺点*：编辑到Commit步骤会打断，浏览器编辑和文件操作
> - 使用**Sublime**编辑文档，配合使用Git插件，编辑完后Commit；
> *优点*：在IDE中可完成Edit+Commit动作
> *缺点*：代码高亮非常弱，预览需要借助第三方软件（如：浏览器）

#####2.访问
Swagger-UI需要如何访问你修改后的文件呢？
Editor和UI都支持解析在线文件，所以我们使用GitHub管理，优点是有版本管理，记住要使用文件的**Raw地址**。
注：不建议使用GitHub Gist，因为每次编辑提交后的地址都会变化

####3.语法规范
一般来说按照示例编写可以解决大部分需求，如果编辑时有特殊需求可参考：
[2.0语法规范](https://github.com/OAI/OpenAPI-Specification/blob/master/versions/2.0.md)

####踩坑
#####1. Swagger-Editor在Chome中输入中文导致错乱，[GitHub Issues](https://github.com/ajaxorg/ace/issues/3027) 
>使用Chrome打开Swagger Editor进行编辑的时候发现输入中文会错乱，会将键盘输入的字母也check进去，最新的Chrome 54也没有解决
	解决方法：使用非Chrome浏览器，IE和Safari没有问题
#####2. UI和Editor配合使用
需求：Editor->编辑->刷新UI，首先发现Editor无法保存编辑的Yaml文档，即使在配置文件中/config/defaults.json设置：
>useBackendForStorage = true

**解决方案**：使用[serve-swagger-editor](https://runkit.com/npm/serve-swagger-editor)
```  javascript
var app = require('serve-swagger-editor')({
	    disableNewUserIntro: true,
	    useBackendForStorage: true,
	    useYamlBackend: true
	}, '/tmp/myspec.yaml');//最后参数代表文件存放地址，建议自行修改
var server = require('http').createServer(app);
server.listen(9090, '0.0.0.0', function () {
    console.log(server.address());
});
```
将上述代码保存为server.js文件存放至：node_modules目录下，运行
``` json
node server.js
```
现在可以在任何地方访问你的Swagger-Editor服务并且不怕修改丢失。

####扩展周边
- [SosoApi](http://www.sosoapi.com/)是一个可以提供在线编辑符合Swagger Yaml标准的在线服务，提供了全程可视傻瓜化的操作，只是创建过程过于分散和碎片化，经常会打断创建文档的思路。优点：给不习惯shell操作的人员提供便利。
- **Swagger Codegen**可以根据符合Swagger标准的文档自动创建出前后端的代码，提供了几乎所有主流代码的模板，这里没有做深入研究，后续再深入。


####总结
对于项目来说这是一门利器，使用得当可以极大的降低前后端的沟通成本。
门槛在于前后端需要尽量使用标准化的代码，以便效用达到最大化。但这是否是另外一种桎梏，相信大家自有判定。


----------


----------


